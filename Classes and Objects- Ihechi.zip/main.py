class Student:
    def __init__(self, name, age, track, score):
        self.name = name
        self.age = age
        self.track = track
        self.score = score
        print("Student name is", name, " and is aged", age, "choice of track is", track, "scored", score)
        pass 



Bob = Student(name="Bob", age=26, track="BE",score=20.90)

class Student:
    def __init__(self, name, age, track, score):
       Bob.change_name = name
       Bob.change_age = age
       Bob.add_track = track
       Bob.get_score = score
       print("Student name is", name, " and is aged", age, "choice of track is", track, "scored", score)
    def speak(self):
        pass
    Peter = Student("Peter", 34, "UI/UX", 34.5)

#Peter = Student(name="Peter", age=34, track="UI/UX",score=27.50)
